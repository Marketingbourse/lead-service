<?php

$globals = $GLOBALS;

class LeadController
{

    private string $url = "https://crm.roikingdom.net/public/legacy/soap.php?wsdl";
    private string $user = "maksym.yevstafiyev@synergybeam.com";
    private string $password = 'v$kvQbr6+KCEh3$1PSEq^FgQX6rQ~awGB#zaQNAsSHN2WxEW?q';
    private string $password_md5 = "30e933474a18db9c121f1f4673900fcd";
    private SoapClient $client;
    private string $secret = 'n2Bn29QVH1';


    public function __construct()
    {
    }

    public function processLeadRequest(string $method, array $lead_data): void
    {

        if ($this->isValidToken($lead_data['auth'])){
            $this->addLeadToSuiteCrm($lead_data ,$method);
        } else {
            http_response_code(401);
            header("Please provide valid token");
        }
        //if (array_key_exists('token', $lead_data) && $this->isValidToken($this->extractToken($lead_data['token']))) {
        //    $this -> addLeadToSuiteCrm($lead_data, $method);
        //} else {
        //    http_response_code(401);
        //    echo('please provide valid token');
        //}
    }


    private function addLeadToSuiteCrm($lead_data, $method): void
    {
        if ($method == 'POST') {
            $this->client = new SoapClient($this->url);
            $this->client->__setLocation($this->url);
            $userAuth = array(
                'user_name' => $this->user,
                'password' => $this->password_md5,
                'version' => '0.1'
            );
            $appName = 'Connector';
            $nameValueList = array();
            $loginResults = $this->client->login($userAuth, $appName, $nameValueList);
            $session_id = $loginResults->id;
            $add_lead = $this->client->set_entry($session_id, "Leads", array(
                array("name" => 'lead_subscription_date_c', "value" => $lead_data['date']),
                array("name" => 'first_name', "value" => $lead_data['first_name']),
                array("name" => 'last_name', "value" => $lead_data['last_name']),
                array("name" => 'email1', "value" => $lead_data['email']),
                array("name" => 'soi_c', "value" => true),
                array("name" => 'doi_c', "value" => false),
                array("name" => 'phone_c', "value" => $lead_data['phone']),
                array("name" => 'vertical_c', "value" => $lead_data['vertical']),
                array("name" => 'aff_id_c', "value" => $lead_data['aff_id']),
                array("name" => 'sign_up_page_url_c', "value" => $lead_data['sing_up_page_url']),
                array("name" => 'source_c', "value" => $lead_data['source']),
                array("name" => 'assigned_user_name', "value" => 'SuiteCRM-lead_Connector'),
                array("name" => 'ip_address_c', "value" => $lead_data['ip_address']),
                array("name" => 'geo_c', "value" => $lead_data['geo']),
                array("name" => 'country_c', "value" => $lead_data['country']),
                array("name" => 'region_c', "value" => $lead_data['region']),
                array("name" => 'province_c', "value" => $lead_data['province']),
                array("name" => 'state_c', "value" => $lead_data['state']),
                array("name" => 'device_c', "value" => $lead_data['device']),
                array("name" => 'os_c', "value" => $lead_data['os']),
                array("name" => 'browser_c', "value" => $lead_data['browser']),
            ));

            $res = var_dump($add_lead);
            $lead_id = $add_lead->id;
            $emercury_lead = array(
                'lead_subscription_date_c' => $lead_data['date'],
                'first_name' => $lead_data['first_name'],
                'last_name' => $lead_data['last_name'],
                'email1' => $lead_data['email'],
                'soi_c' => true,
                'doi_c' => false,
                'phone_c' => $lead_data['phone'],
                'vertical_c' => $lead_data['vertical'],
                'aff_id_c' => $lead_data['aff_id'],
                'sign_up_page_url_c' => $lead_data['sing_up_page_url'],
                'source_c' => $lead_data['source'],
                'ip_address_c' => $lead_data['ip_address'],
                'geo_c' => $lead_data['geo'],
                'country_c' => $lead_data['country'],
                'region_c' => $lead_data['region'],
                'province_c' => $lead_data['province'],
                'state_c' => $lead_data['state'],
                'device_c' => $lead_data['device'],
                'os_c' => $lead_data['os'],
                'browser_c' => $lead_data['browser'],
                'id_c' => $lead_id
            );
            $this->curlRequest("POST", 'http://146.190.231.75:2999', $emercury_lead, []);
            echo $lead_id;
            http_response_code(201);
        } else {
            http_response_code(405);
            header("Allow: POST");
        }
    }


    /**
     * @throws Exception
     */
    private function isValidToken($token): bool
    {
        $decoded = explode("; ", base64_decode($token));
        $secretFromToken = ltrim($decoded[0], "{");
        $isSecretValid = $secretFromToken == $this->secret;
        $date_time_from_token_raw = $decoded[1];
        $date_time_from_token = new DateTimeImmutable($date_time_from_token_raw);
        $ttl_for_token = (new DateTimeImmutable())->sub(new DateInterval('PT' . 3600 . 'S'));
        $isDateStampValid = $date_time_from_token > $ttl_for_token;
        return $isSecretValid;
    }

    private function curlRequest($method, $url, $post_data = [], $headers = [])
    {
        echo 'request to service';
        $curl = curl_init();
        if (count($headers) != 0) {
            $contentHeaders = array(
                "Content-Type: application/json",
                "cache-control: no-cache"
            );
            $headers = array_merge($headers, $contentHeaders);
        } else {
            $headers = array(
                "Content-Type: application/json",
                "cache-control: no-cache"
            );
        }
        curl_setopt_array($curl, array(
            //CURLOPT_PORT => '2999',
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_POSTFIELDS => $post_data ? json_encode($post_data) : "",
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_FOLLOWLOCATION => true,
            CURLINFO_HEADER_OUT => true,
            CURLOPT_VERBOSE => 1,
            CURLOPT_HEADER => 1,
            CURLOPT_POST => 1,
            CURLOPT_TIMEOUT_MS => 2000
        ));


        $response = curl_exec($curl);
        $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $responseHeader = substr($response, 0, $header_size);
        $httpCode = curl_getinfo($curl)['http_code'];
        $body = substr($response, $header_size);
        $headersArray = [];//parseHeaders($responseHeader);
        $time = round(microtime(true) - $_SERVER["REQUEST_TIME_FLOAT"], 4);

        try {
            $resp = json_decode($response, true);
            $dataInsert[] = $url;//$_SERVER['REQUEST_SCHEME'] . '://' .$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
            $dataInsert[] = $method;
            $dataInsert[] = json_encode($post_data);
            $dataInsert[] = $body;
            $dataInsert[] = json_encode($headers);
            $dataInsert[] = json_encode($headersArray);
            $dataInsert[] = $time;
            $dataInsert[] = 'php';
            $dataInsert[] = $httpCode;
        } catch (Exception $e) {
            info($e->getMessage());
            echo $e->getMessage();
        }
        curl_close($curl);
        return ($body ==null)? []: json_decode($body, true);
    }
}









