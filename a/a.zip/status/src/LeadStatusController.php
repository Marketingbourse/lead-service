<?php

$globals = $GLOBALS;

class LeadStatusController
{

    private string $url = "https://crm.roikingdom.net/public/legacy/soap.php?wsdl";
    private string $user = "maksym.yevstafiyev@synergybeam.com";
    private string $password = 'v$kvQbr6+KCEh3$1PSEq^FgQX6rQ~awGB#zaQNAsSHN2WxEW?q';
    private string $password_md5 = "30e933474a18db9c121f1f4673900fcd";
    private SoapClient $client;

    public function __construct()
    {
    }

    public function processLeadUpdateRequest(string $method, array $id_obj): void
    {
        if ($method == 'POST') {
            $this->client = new SoapClient($this->url);
            $this->client->__setLocation($this->url);
            $userAuth = array(
                'user_name' => $this->user,
                'password' => $this->password_md5,
                'version' => '0.1'
            );
            $appName = 'Connector';
            $nameValueList = array();
            $loginResults = $this->client->login($userAuth, $appName, $nameValueList);
            $session_id = $loginResults->id;
            $modify_lead = $this->client->set_entry($session_id, "Leads", array(
                array("name" => 'id', "value" => $id_obj['id']),
                array("name" => 'doi_c', "value" => true),
            ));

            $res = $modify_lead;
            echo var_dump($res);
            echo $id_obj['id'];
            http_response_code(201);
        } else {
            http_response_code(405);
            header("Allow: PATCH");
        }
    }
}









